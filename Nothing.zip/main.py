import pygame

from worlds import Worlds
from config import *

resource = Resource()

file_check_result = resource.check_files()
print(file_check_result[1])
if not file_check_result[0]:
    exit(FileNotFoundError)

# Инициализация Pygame
pygame.init()

# Создание окна с начальным размером
screen = pygame.display.set_mode((600, 500), pygame.RESIZABLE)

def set_scene(scene):
    scene()

worlds = Worlds(screen, set_scene)

set_scene(worlds.home_scene())

# Завершение Pygame
pygame.quit()
