import pygame
from colors import Colors
from player import Player

class Worlds:
    def __init__(self, screen : pygame.display, set_scene_def : object):
        self.screen = screen

    def home_scene(self):
        player = Player(300, 250, 20)

        running = True
        while running:
            # Обработка событий
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    exit(0)

                # Изменение размера окна
                if event.type == pygame.VIDEORESIZE:
                    self.screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)

                player.new_event(event)

            screen_width, screen_height = self.screen.get_size()

            player.update(screen_width, screen_height)

            self.screen.fill((0, 0, 0))

            # Получение текущего размера экрана
            screen_width, screen_height = self.screen.get_size()

            # Рассчитываем масштаб для растягивания
            scale_x = screen_width / 600  # Исходная ширина окна 600
            scale_y = screen_height / 500  # Исходная высота окна 500

            player.draw(self.screen)
            player.move()

            # Обновление экрана
            pygame.display.flip()
