import pygame
from colors import Colors

class Player:
    def __init__(self, x, y, radius):
        self.x = x
        self.y = y

        self.radius = radius
        self.original_radius = radius

        self.moving_left = False
        self.moving_right = False
        self.moving_up = False
        self.moving_down = False

        self.is_move = True

    def draw(self, screen):
        pygame.draw.circle(screen, Colors.green, (self.x, self.y), self.radius)

    def update(self, screen_width, screen_height):
        scale_x = screen_width / 600
        scale_y = screen_height / 500
        self.radius = int(self.original_radius * max(scale_x, scale_y))

    def new_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                self.moving_left = True
            if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                self.moving_right = True
            if event.key == pygame.K_UP or event.key == pygame.K_w:
                self.moving_up = True
            if event.key == pygame.K_DOWN or event.key == pygame.K_s:
                self.moving_down = True

        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT or event.key == pygame.K_a:
                self.moving_left = False
            if event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                self.moving_right = False
            if event.key == pygame.K_UP or event.key == pygame.K_w:
                self.moving_up = False
            if event.key == pygame.K_DOWN or event.key == pygame.K_s:
                self.moving_down = False

        self.move()

    def move(self):
        if self.is_move:
            if self.moving_left:
                self.x -= 0.1
            if self.moving_right:
                self.x += 0.1
            if self.moving_up:
                self.y -= 0.1
            if self.moving_down:
                self.y += 0.1
